@extends('layouts.backend.app')

@section('content')
@push('page-css')
@endpush
<div class="main-content-inner">
    <div class="breadcrumbs ace-save-state" id="breadcrumbs">
        <ul class="breadcrumb">
            <li>
                <i class="ace-icon fa fa-home home-icon"></i>
                <a href="#">Home</a>
            </li>
            <li class="active">Dashboard</li>
        </ul><!-- /.breadcrumb -->

        <div class="nav-search" id="nav-search">
            <form class="form-search">
                <span class="input-icon">
                    <input type="text" placeholder="Search ..." class="nav-search-input" id="nav-search-input" autocomplete="off" />
                    <i class="ace-icon fa fa-search nav-search-icon"></i>
                </span>
            </form>
        </div><!-- /.nav-search -->
    </div>

    <div class="page-content">
        <div class="page-header">
            <h1>
                Dashboard
                <small>
                    <i class="ace-icon fa fa-angle-double-right"></i>
                    overview &amp; stats
                </small>
            </h1>
        </div><!-- /.page-header -->

        <div class="row">
            <div class="col-xs-12 float-right" style="text-align:right">
                <a href="#modal-table" role="button" data-toggle="modal" class="btn btn-sm btn-info m-2" style="margin-bottom:10px">Add +</a>
            </div>
            <div class="col-xs-12">
                <div class="table-header">
                    Results for "Latest Organizations"
                </div>
                <!-- Organization List -->
                <div>
                    <table id="dynamic-table" class="table table-striped table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>S. No.</th>
                                <th>Eng.Name</th>
                                <th>Bng.Name</th>
                                <th>Email</th>
                                <th>Mobile</th>
                                <th>Title</th>
                                <th>Subtitle</th>
                                <th>Description</th>
                                <th>Footer One</th>
                                <th>Footer Two</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            @foreach($organizations as $key => $organization)
                            <tr>
                                <td class="center">{{$key + 1}}</td>
                                <td>{{$organization->eng_name}}</td>
                                <td>{{$organization->bng_name}}</td>
                                <td>{{$organization->email}}</td>
                                <td>{{$organization->mobile}}</td>
                                <td>{{$organization->title}}</td>
                                <td>{{$organization->subtitle}}</td>
                                <td>{{$organization->description}}</td>
                                <td>{{$organization->footer_one}}</td>
                                <td>{{$organization->footer_two??''}}</td>
                                <td>
                                    <div class="hidden-sm hidden-xs action-buttons">
                                        <a class="blue" href="#" data-id="{{$organization->id}}" onclick="getOrganizeIdForView(this)">
                                            <i class="ace-icon fa fa-search-plus bigger-130"></i>
                                        </a>

                                        <a class="green" href="#" data-rel="tooltip" data-id="{{$organization->id}}" title="Edit" onclick="getOrganizeId(this)">
                                            <i class="ace-icon fa fa-pencil bigger-130"></i>
                                        </a>

                                        <a class="red destroy" href="#" data-route="{{route('organization.delete', $organization->id)}}">
                                            <i class="ace-icon fa fa-trash-o bigger-130"></i>
                                        </a>
                                    </div>

                                    {{-- <div class="hidden-md hidden-lg">
                                        <div class="inline pos-rel">
                                            <button class="btn btn-minier btn-yellow dropdown-toggle" data-toggle="dropdown" data-position="auto">
                                                <i class="ace-icon fa fa-caret-down icon-only bigger-120"></i>
                                            </button>

                                            <ul class="dropdown-menu dropdown-only-icon dropdown-yellow dropdown-menu-right dropdown-caret dropdown-close">
                                                <li>
                                                    <a href="#" class="tooltip-info" data-rel="tooltip" title="View">
                                                        <span class="blue">
                                                            <i class="ace-icon fa fa-search-plus bigger-120"></i>
                                                        </span>
                                                    </a>
                                                </li>

                                                <li>
                                                    <a href="#" class="tooltip-success" data-rel="tooltip" data-id="{{$organization->id}}" title="Edit">
                                                        <span class="green">
                                                            <i class="ace-icon fa fa-pencil-square-o bigger-120"></i>
                                                        </span>
                                                    </a>
                                                </li>

                                                <li>
                                                    <a href="#" class="tooltip-error" data-rel="tooltip" title="Delete">
                                                        <span class="red">
                                                            <i class="ace-icon fa fa-trash-o bigger-120"></i>
                                                        </span>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div> --}}
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
            <!-- Organization Entry Modal -->
            <div id="modal-table" class="modal fade" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header no-padding">
                            <div class="table-header" style="padding:5px;">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                    <span class="white">&times;</span>
                                </button>
                                Organization Entry Form
                            </div>
                        </div>
                        
                        <div class="modal-body no-padding">
                            {{-- <div class="modal_inner_container"> --}}
                                <form action="#" method="post" id="organizationInfo" class="common_class" enctype="multipart/form-data">
                                    @csrf
                                    <div class="modal_inner_container" style="padding:8px;display:inline">
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label for="eng_name">English Name<span class="frequired">*</span></label>
                                                <input type="text" class="form-control form-control-sm required" id="name" name="eng_name" autocomplete="off">
                                                @if($errors->has('eng_name'))
                                                    <span class="danger">{{ $errors->first('eng_name') }}</span>
                                                @endif
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="bng_name">Bangla Name<span class="frequired">*</span></label>
                                                <input type="text" class="form-control form-control-sm required" id="name" name="bng_name" autocomplete="off">
                                                @if($errors->has('bng_name'))
                                                    <span class="danger">{{ $errors->first('bng_name') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label for="email">E-mail<span class="frequired">*</span></label>
                                                <input type="email" class="form-control form-control-sm required" id="email" name="email">
                                                @if($errors->has('email'))
                                                    <span class="danger">{{ $errors->first('email') }}</span>
                                                @endif
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="mobile">Mobile<span class="frequired">*</span></label>
                                                <input type="mobile" class="form-control form-control-sm required" id="mobile" name="mobile">
                                                @if($errors->has('mobile'))
                                                    <span class="danger">{{ $errors->first('mobile') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label for="title">Title<span class="frequired">*</span></label>
                                                <input type="title" class="form-control form-control-sm required" id="title" name="title">
                                                @if($errors->has('title'))
                                                    <span class="danger">{{ $errors->first('title') }}</span>
                                                @endif
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="subtitle">Sub-Title<span class="frequired">*</span></label>
                                                <input type="subtitle" class="form-control form-control-sm required" id="subtitle" name="subtitle">
                                                @if($errors->has('subtitle'))
                                                    <span class="danger">{{ $errors->first('subtitle') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-9">
                                                <label for="description">Descriptions<span class="frequired">*</span></label>
                                                <textarea class="form-control form-control-sm required" id="description" name="description"></textarea>
                                                @if($errors->has('description'))
                                                    <span class="danger">{{ $errors->first('description') }}</span>
                                                @endif
                                            </div>
                                            <div class="form-group col-md-3">
                                                <label for="status">Status<span class="frequired">*</span></label>
                                                <select name="status" class="form-control form-control-sm " id="status">
                                                    <option value="1" selected>Active</option>
                                                    <option value="0">InActive</option>
                                                </select>
                                                @if($errors->has('status'))
                                                    <span class="danger">{{ $errors->first('status') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-12">
                                                <label for="footer_one">Footer One<span class="frequired">*</span></label>
                                                <textarea class="form-control form-control-sm required" id="footer_one" name="footer_one"></textarea>
                                                @if($errors->has('footer_one'))
                                                    <span class="danger">{{ $errors->first('footer_one') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-12">
                                                <label for="footer_two">Footer Two<span class="frequired">*</span></label>
                                                <textarea class="form-control form-control-sm required" id="footer_two" name="footer_two"></textarea>
                                                @if($errors->has('footer_two'))
                                                    <span class="danger">{{ $errors->first('footer_two') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col-md-6">
                                                <label for="image_one">Image One<span class="frequired">*</span></label>
                                                <input type="file" class="form-control form-control-sm required" id="image_one" name="image_one">
                                                @if($errors->has('image_one'))
                                                    <span class="danger">{{ $errors->first('image_one') }}</span>
                                                @endif
                                            </div>
                                            <div class="form-group col-md-6">
                                                <label for="image_two">Image Two<span class="frequired">*</span></label>
                                                <input type="file" class="form-control form-control-sm required" id="image_two" name="image_two">
                                                @if($errors->has('image_two'))
                                                    <span class="danger">{{ $errors->first('image_two') }}</span>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            {{-- </div> --}}
                        </div>
                        <div class="modal-footer no-margin-top">
                            <button class="btn btn-sm btn-danger pull-right" data-dismiss="modal">
                                <i class="ace-icon fa fa-times"></i>
                                Close
                            </button>
                            &nbsp; &nbsp; &nbsp;
                            <button type="submit" class="btn btn-sm btn-info pull-right" id="organizationSubmit" aria-hidden="true" onclick="submitForm()" style="margin-right:6px">
                                <i class="ace-icon fa fa-check bigger-110"></i>
                                Submit
                            </button>
                        </div>
                    </div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div>
            <!-- Organization Update Modal -->
            <div id="modal-update" class="modal fade" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header no-padding">
                            <div class="table-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                    <span class="white">&times;</span>
                                </button>
                                Organization Entry Form
                            </div>
                        </div>
                        <div class="modal-body no-padding">
                            
                        </div>
                        <div class="modal-footer no-margin-top">
                            <button class="btn btn-sm btn-danger pull-right" data-dismiss="modal">
                                <i class="ace-icon fa fa-times"></i>
                                Close
                            </button>
                            &nbsp; &nbsp; &nbsp;
                            <button type="submit" class="btn btn-sm btn-info pull-right" id="organizationUpdate" aria-hidden="true" onclick="organizationUpdate()" style="margin-right:6px">
                                <i class="ace-icon fa fa-check bigger-110"></i>
                                Submit
                            </button>
                        </div>
                    </div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div>
            <!-- Organization View Modal -->
            <div id="modal-view" class="modal fade" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header no-padding">
                            <div class="table-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                    <span class="white">&times;</span>
                                </button>
                                Organization View
                            </div>
                        </div>
                        <div class="modal-body no-padding">
                            
                        </div>
                        <div class="modal-footer">
                            <div class="col-md-offset-3 col-md-9">
                                <button type="button" class="btn" id="cancelBtn" data-dismiss="modal" aria-hidden="true" >
                                    <i class="ace-icon fa fa-undo bigger-110"></i>
                                    Cancel
                                </button>
                            </div>
                        </div>
                    </div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div>
        </div>
    </div><!-- /.page-content -->
</div>
  @endsection
  @push('page-js')
    <script type="text/javascript">
    // Mobile number valiation
    $.validator.addMethod("mobileNumber", function(value, element) {
    return this.optional(element) || /^\d{11}$/.test(value);
    }, "Please enter a valid 11-digit mobile number.");

    $('#organizationInfo').validate({
        errorClass: 'danger',
        successClass: 'success',
        errorElement: "span",
        highlight: function (element, errorClass) {
            $(element).removeClass(errorClass);
            $(element).parent('.form-group').addClass('error');
        },
        unhighlight: function (element, errorClass) {
            $(element).removeClass(errorClass);
            $(element).parent('.form-group').removeClass('error');
        },
        errorPlacement: function (error, element) {
            if (element.attr('name') === 'member_status') {
                error.appendTo($('.radio-error'));
            } else if (element[0].tagName === "SELECT") {
                error.insertAfter(element);
                // error.insertAfter(element.siblings('.select2-container'));
            } else if (element.attr('name') === 'member_image') {
                error.appendTo($('.imgPreview'));
            } else if (element.attr('name') === 'birth_date') {
                error.appendTo($('.birth_date_error'));
            }
            else{
                error.insertAfter(element);
            }
        },

        rules: {
            mobile: {
                required: true,
                mobileNumber: true,
            },
            email: {
                required: true,
            },
        },
        messages: {
            mobile: {
                required: "Enter your mobile number.",
                mobileNumber: "Enter a valid 11-digit number.",
            },
            email: {
                required: "Enter your email.",
            },
        },
    });
    $('#organizationUpdateInfo').validate({
        errorClass: 'danger',
        successClass: 'success',
        errorElement: "span",
        highlight: function (element, errorClass) {
            $(element).removeClass(errorClass);
            $(element).parent('.form-group').addClass('error');
        },
        unhighlight: function (element, errorClass) {
            $(element).removeClass(errorClass);
            $(element).parent('.form-group').removeClass('error');
        },
        errorPlacement: function (error, element) {
            if (element.attr('name') === 'member_status') {
                error.appendTo($('.radio-error'));
            } else if (element[0].tagName === "SELECT") {
                error.insertAfter(element);
                // error.insertAfter(element.siblings('.select2-container'));
            } else if (element.attr('name') === 'member_image') {
                error.appendTo($('.imgPreview'));
            } else if (element.attr('name') === 'birth_date') {
                error.appendTo($('.birth_date_error'));
            }
            else{
                error.insertAfter(element);
            }
        },

        rules: {
            mobile: {
                required: true,
                mobileNumber: true,
            },
            email: {
                required: true,
            },
        },
        messages: {
            mobile: {
                required: "Enter your mobile number.",
                mobileNumber: "Enter a valid 11-digit number.",
            },
            email: {
                required: "Enter your email.",
            },
        },
    });

    function submitForm() {
        // Get form data
        event.preventDefault();
        if($('#organizationInfo').valid()) {
        var formData = new FormData($('#organizationInfo')[0]);
        // AJAX request
        $.ajax({
            type: "POST",
            url: "{{route('organization.store')}}",
            data: formData,
            contentType: false,
            processData: false,
            success: function(response) {
                $('#modal-table').modal('hide');
                Swal.fire({
                    title: 'Great job',
                    text: "Data Successfully Submitted!",
                    type: 'success',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes'
                    }).then((result) => {
                    if(result){
                        // Do Stuff here for success
                        location.reload();
                    }else{
                        // something other stuff
                    }

                })
            },
            error: function(error) {
                Swal.fire('', 'Error submitting form', 'error');
            }
        });
        }else{
            return false;
        }
    }
    function getOrganizeIdForView(obj) {
        let organizeId = $(obj).attr("data-id");
        // AJAX request
        $.ajax({
            type: "GET",
            url: "{{route('organization.show')}}",
            data: {
                id: organizeId
            },
            success: function(response) {
                $('#modal-view .modal-body').html(response);
                $('#modal-view').modal('show');
            },
            error: function(error) {
                Swal.fire('', 'Error submitting form', 'error');
            }
        });
    }
    function getOrganizeId(obj) {
        let organizeId = $(obj).attr("data-id");
        // AJAX request
        $.ajax({
            type: "GET",
            url: "{{route('organization.edit')}}",
            data: {
                id: organizeId
            },
            success: function(response) {
                $('#modal-update .modal-body').html(response);
                $('#modal-update').modal('show');
                // Swal.fire('', 'Data Successfully Submitted', 'success');
                // location.reload();
            },
            error: function(error) {
                Swal.fire('', 'Error submitting form', 'error');
            }
        });
    }

    function organizationUpdate() {
        // Get form data
        event.preventDefault();

        if($('#organizationUpdateInfo').valid()) {
            var formData = new FormData($('#organizationUpdateInfo')[0]);
            // AJAX request
            $.ajax({
                type: "post",
                url: "{{route('organization.update')}}",
                data: formData,
                contentType: false,
                processData: false,
                success: function(response) {
                    $('#modal-update').modal('hide');
                    Swal.fire({
                        title: 'Great job',
                        text: "Data Successfully Updated!",
                        type: 'success',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes'
                        }).then((result) => {
                        if(result){
                            // Do Stuff here for success
                            location.reload();
                        }else{
                            // something other stuff
                        }

                    })
                },
                error: function(error) {
                    Swal.fire('', 'Error submitting form', 'error');
                }
            });
        }else{
            return false;
        }
    }

    $(document).ready(function() {
        jQuery(function($) {

            var myTable = 
            $('#dynamic-table')
            .DataTable( {
                "order": [[ 0, "desc" ]]
            } );
        
            
            $.fn.dataTable.Buttons.defaults.dom.container.className = 'dt-buttons btn-overlap btn-group btn-overlap';
            
            new $.fn.dataTable.Buttons( myTable, {
                buttons: [
                {
                    "extend": "colvis",
                    "text": "<i class='fa fa-search bigger-110 blue'></i> <span class='hidden'>Show/hide columns</span>",
                    "className": "btn btn-white btn-primary btn-bold",
                    columns: ':not(:first):not(:last)'
                },
                {
                    "extend": "copy",
                    "text": "<i class='fa fa-copy bigger-110 pink'></i> <span class='hidden'>Copy to clipboard</span>",
                    "className": "btn btn-white btn-primary btn-bold"
                },
                {
                    "extend": "csv",
                    "text": "<i class='fa fa-database bigger-110 orange'></i> <span class='hidden'>Export to CSV</span>",
                    "className": "btn btn-white btn-primary btn-bold"
                },
                {
                    "extend": "excel",
                    "text": "<i class='fa fa-file-excel-o bigger-110 green'></i> <span class='hidden'>Export to Excel</span>",
                    "className": "btn btn-white btn-primary btn-bold"
                },
                {
                    "extend": "pdf",
                    "text": "<i class='fa fa-file-pdf-o bigger-110 red'></i> <span class='hidden'>Export to PDF</span>",
                    "className": "btn btn-white btn-primary btn-bold"
                },
                {
                    "extend": "print",
                    "text": "<i class='fa fa-print bigger-110 grey'></i> <span class='hidden'>Print</span>",
                    "className": "btn btn-white btn-primary btn-bold",
                    autoPrint: false,
                    message: 'This print was produced using the Print button for DataTables'
                }		  
                ]
            } );

            myTable.buttons().container().appendTo( $('.tableTools-container'));
            
            //style the message box
            var defaultCopyAction = myTable.button(1).action();
            myTable.button(1).action(function (e, dt, button, config) {
                defaultCopyAction(e, dt, button, config);
                $('.dt-button-info').addClass('gritter-item-wrapper gritter-info gritter-center white');
            });
            
            
            var defaultColvisAction = myTable.button(0).action();
            myTable.button(0).action(function (e, dt, button, config) {
                
                defaultColvisAction(e, dt, button, config);
                
                
                if($('.dt-button-collection > .dropdown-menu').length == 0) {
                    $('.dt-button-collection')
                    .wrapInner('<ul class="dropdown-menu dropdown-light dropdown-caret dropdown-caret" />')
                    .find('a').attr('href', '#').wrap("<li />")
                }
                $('.dt-button-collection').appendTo('.tableTools-container .dt-buttons')
            });
        
            setTimeout(function() {
                $($('.tableTools-container')).find('a.dt-button').each(function() {
                    var div = $(this).find(' > div').first();
                    if(div.length == 1) div.tooltip({container: 'body', title: div.parent().text()});
                    else $(this).tooltip({container: 'body', title: $(this).text()});
                });
            }, 500);
            
            myTable.on( 'select', function ( e, dt, type, index ) {
                if ( type === 'row' ) {
                    $( myTable.row( index ).node() ).find('input:checkbox').prop('checked', true);
                }
            } );
            myTable.on( 'deselect', function ( e, dt, type, index ) {
                if ( type === 'row' ) {
                    $( myTable.row( index ).node() ).find('input:checkbox').prop('checked', false);
                }
            } );
        
            //table checkboxes
            $('th input[type=checkbox], td input[type=checkbox]').prop('checked', false);
            
            //select/deselect all rows according to table header checkbox
            $('#dynamic-table > thead > tr > th input[type=checkbox], #dynamic-table_wrapper input[type=checkbox]').eq(0).on('click', function(){
                var th_checked = this.checked;//checkbox inside "TH" table header
                
                $('#dynamic-table').find('tbody > tr').each(function(){
                    var row = this;
                    if(th_checked) myTable.row(row).select();
                    else  myTable.row(row).deselect();
                });
            });
            
            //select/deselect a row when the checkbox is checked/unchecked
            $('#dynamic-table').on('click', 'td input[type=checkbox]' , function(){
                var row = $(this).closest('tr').get(0);
                if(this.checked) myTable.row(row).deselect();
                else myTable.row(row).select();
            });
        
            $(document).on('click', '#dynamic-table .dropdown-toggle', function(e) {
                e.stopImmediatePropagation();
                e.stopPropagation();
                e.preventDefault();
            });
            
            //And for the first simple table, which doesn't have TableTools or dataTables
            //select/deselect all rows according to table header checkbox
            var active_class = 'active';
            $('#simple-table > thead > tr > th input[type=checkbox]').eq(0).on('click', function(){
                var th_checked = this.checked;//checkbox inside "TH" table header
                
                $(this).closest('table').find('tbody > tr').each(function(){
                    var row = this;
                    if(th_checked) $(row).addClass(active_class).find('input[type=checkbox]').eq(0).prop('checked', true);
                    else $(row).removeClass(active_class).find('input[type=checkbox]').eq(0).prop('checked', false);
                });
            });
            
            //select/deselect a row when the checkbox is checked/unchecked
            $('#simple-table').on('click', 'td input[type=checkbox]' , function(){
                var $row = $(this).closest('tr');
                if($row.is('.detail-row ')) return;
                if(this.checked) $row.addClass(active_class);
                else $row.removeClass(active_class);
            });
        
            
            //add tooltip for small view action buttons in dropdown menu
            $('[data-rel="tooltip"]').tooltip({placement: tooltip_placement});
            
            //tooltip placement on right or left
            function tooltip_placement(context, source) {
                var $source = $(source);
                var $parent = $source.closest('table')
                var off1 = $parent.offset();
                var w1 = $parent.width();
        
                var off2 = $source.offset();
                //var w2 = $source.width();
        
                if( parseInt(off2.left) < parseInt(off1.left) + parseInt(w1 / 2) ) return 'right';
                return 'left';
            }
            
            $('.show-details-btn').on('click', function(e) {
                e.preventDefault();
                $(this).closest('tr').next().toggleClass('open');
                $(this).find(ace.vars['.icon']).toggleClass('fa-angle-double-down').toggleClass('fa-angle-double-up');
            });

        })
    });
        
    </script>
@endpush